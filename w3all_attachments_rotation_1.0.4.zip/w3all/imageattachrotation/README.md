# Attachments Images Rotation

## Installation

Copy the extension to phpBB/ext/w3all/imageattachrotation

Go to "ACP" > "Customise" > "Extensions" and enable the "Attachments Images Rotation" extension.

## License

[GPLv2](license.txt)
